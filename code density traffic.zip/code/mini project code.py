#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, LSTM, Embedding, SpatialDropout1D, Conv1D, MaxPooling1D, Dropout
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report

# Preprocessing function
def preprocess_data(data, tokenizer=None, max_words=5000, max_len=100, fit_tokenizer=True):
    """
    Preprocess the input data for the model.
    Combines 'title' and 'text' columns into a 'content' column for text processing.
    """
    # Combine title and text into a single column 'content'
    data['content'] = data['title'] + ' ' + data['text']
    
    # Tokenization
    if fit_tokenizer:
        tokenizer = Tokenizer(num_words=max_words)
        tokenizer.fit_on_texts(data['content'])
    
    sequences = tokenizer.texts_to_sequences(data['content'])
    padded_sequences = pad_sequences(sequences, maxlen=max_len)
    return padded_sequences, tokenizer

# Function to build the model
def build_model(max_words, max_len):
    """
    Build the LSTM-CNN hybrid model.
    """
    model = Sequential()
    model.add(Embedding(max_words, 128, input_length=max_len))
    model.add(SpatialDropout1D(0.2))
    model.add(Conv1D(filters=64, kernel_size=5, activation='relu'))
    model.add(MaxPooling1D(pool_size=2))
    model.add(LSTM(100, return_sequences=True))
    model.add(Dropout(0.2))
    model.add(LSTM(100))
    model.add(Dropout(0.2))
    model.add(Dense(1, activation='sigmoid'))
    model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
    return model

# Load training dataset (Fake.csv)
train_data = pd.read_csv('Fake.csv')  # Replace with the actual path to Fake.csv

# Generate random labels for demonstration (0 for real, 1 for fake)
np.random.seed(42)  # Set seed for reproducibility
train_data['label'] = np.random.choice([0, 1], size=len(train_data))

# Preprocess the training data
max_words = 5000
max_len = 100

X_train_data, tokenizer = preprocess_data(train_data, max_words=max_words, max_len=max_len)
y_train_data = train_data['label'].values

# Split training data into train and validation sets
X_train, X_val, y_train, y_val = train_test_split(X_train_data, y_train_data, test_size=0.2, random_state=42)

# Build and train the model
model = build_model(max_words, max_len)
batch_size = 64
epochs = 5
model.fit(X_train, y_train, epochs=epochs, batch_size=batch_size, validation_data=(X_val, y_val))

# Evaluate the model on validation data
loss, accuracy = model.evaluate(X_val, y_val, verbose=0)
print(f'Validation Accuracy: {accuracy:.2f}')

# Load new data (new_data.csv) for prediction
new_data = pd.read_excel('new_data1.xlsx')  # Replace with the actual path to new_data.csv

# Preprocess the new data
new_X_data, _ = preprocess_data(new_data, tokenizer=tokenizer, fit_tokenizer=False)

# Predict labels for the new data
new_predictions = (model.predict(new_X_data) > 0.5).astype("int32")

# Add predictions to new_data DataFrame
new_data['predicted_label'] = new_predictions

# Save the results to a new CSV file
new_data.to_csv('new_data_with_predictions.csv', index=False)
print("Predictions saved to 'new_data_with_predictions.csv'")


# In[ ]:




